package factoryModule;

import commandModule.Command;

public abstract class CommandFactory {

	public Command createCommand() {
		return null;
	}
}
