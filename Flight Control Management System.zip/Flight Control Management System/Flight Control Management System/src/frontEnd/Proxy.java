package frontEnd;

public abstract class Proxy {

}
