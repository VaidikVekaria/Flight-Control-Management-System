package commandModule;

public abstract class Command {
	
	public Result doAction() {
		return null;
	}

}
