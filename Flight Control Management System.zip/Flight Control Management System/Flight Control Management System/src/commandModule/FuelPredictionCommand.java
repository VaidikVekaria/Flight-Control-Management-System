package commandModule;

public class FuelPredictionCommand extends Command {

}
