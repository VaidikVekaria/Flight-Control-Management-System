package controlSurfacesModule;

public interface IControlActuator {
	public void update(int curLat, int curLon, int nextLat, int nextLon);

}
