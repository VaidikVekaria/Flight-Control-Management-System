package GPSReaderModule;

import autopilotModule.*;

public interface IGPSReader {
	public Coordinates readCoordinates();

}
