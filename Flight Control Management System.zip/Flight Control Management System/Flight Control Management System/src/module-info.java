/**
 * 
 */
/**
 * @author kkont
 *
 */
module Lab5 {
}